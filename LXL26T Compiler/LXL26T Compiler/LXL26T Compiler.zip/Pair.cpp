#include "Pair.h"

Pair::Pair(int arg, int value)
{
	this->arg = arg;
	this->value = value;
}

Pair::Pair(const Pair& p)
{
	this->arg = p.arg;
	this->value = p.value;
}

Pair& Pair::operator=(Pair& p)
{
	this->arg = p.arg;
	this->value = p.value;
	return *this;
}

void Pair::invert_pair()
{
	swap(arg, value);
}

bool Pair::operator==(Pair& p)
{
	return this->arg == p.arg;
}

bool Pair::operator!=(Pair& p)
{
	return !(*this == p);
}

bool Pair::operator<(Pair& p)
{
	return this->arg < p.arg;
}

bool Pair::operator>(Pair& p)
{
	return this->arg > p.arg;
}

bool Pair::operator<=(Pair& p)
{
	return this->arg <= p.arg;
}

bool Pair::operator>=(Pair& p)
{
	return this->arg >= p.arg;
}

bool Pair::equal(Pair& p)
{
	return this->arg == p.arg && this->value == p.value;
}

Pair Pair::operator+(Pair& p)
{
	Pair a(*this);
	a.value = a.value + p.value;
	return a;
}

Pair Pair::operator-(Pair& p)
{
	Pair a(*this);
	a.value = a.value - p.value;
	return a;
}

Pair Pair::operator*(Pair& p)
{
	Pair a(*this);
	a.value = a.value * p.value;
	return a;
}

Pair Pair::operator/(Pair& p)
{
	Pair a(*this);
	a.value = a.value / p.value;
	return a;
}

Pair Pair::operator%(Pair& p)
{
	Pair a(*this);
	a.value = a.value % p.value;
	return a;
}

Pair& Pair::operator+=(Pair& p)
{
	this->value = this->value + p.value;
	return *this;
}

Pair& Pair::operator-=(Pair& p)
{
	this->value = this->value - p.value;
	return *this;
}

Pair& Pair::operator*=(Pair& p)
{
	this->value = this->value * p.value;
	return *this;
}

Pair& Pair::operator/=(Pair& p)
{
	this->value = this->value / p.value;
	return *this;
}

Pair& Pair::operator%=(Pair& p)
{
	this->value = this->value % p.value;
	return *this;
}

int Pair::get_value()
{
	return this->value;
}

int Pair::get_arg()
{
	return this->arg;
}

ostream& operator<<(ostream& os, const Pair& p)
{
	try {
		if (&p != nullptr) {
			os << p.arg << ">" << p.value;
		}
		else throw "Not a Pair";
	}
	catch (const char* e) {
		os << e;
		return os;
	}
	return os;
}

istream& operator>>(istream& is, Pair& p)
{
	char a;
	return is >> p.arg >> a >> p.value;
}
