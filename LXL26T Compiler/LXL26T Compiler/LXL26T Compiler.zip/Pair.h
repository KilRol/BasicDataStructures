#pragma once
#include <iostream>

using namespace std;

class Pair
{
private:
	int arg;
	int value;
public:
	Pair(int arg = int(), int value = int());
	Pair(const Pair& p);
	Pair& operator=(Pair& p);
	void invert_pair();

	//Relations
	bool operator==(Pair& p);
	bool operator!=(Pair& p);
	bool operator<(Pair& p);
	bool operator>(Pair& p);
	bool operator<=(Pair& p);
	bool operator>=(Pair& p);
	bool equal(Pair& p);

	//Arithmetic operations
	Pair operator+(Pair& p);
	Pair operator-(Pair& p);
	Pair operator*(Pair& p);
	Pair operator/(Pair& p);
	Pair operator%(Pair& p);
	Pair& operator+=(Pair& p);
	Pair& operator-=(Pair& p);
	Pair& operator*=(Pair& p);
	Pair& operator/=(Pair& p);
	Pair& operator%=(Pair& p);

	//Getters
	int get_value();
	int get_arg();

	//Stream I/O
	friend ostream& operator<<(ostream& os, const Pair& p);
	friend istream& operator>>(istream& is, Pair& p);
};