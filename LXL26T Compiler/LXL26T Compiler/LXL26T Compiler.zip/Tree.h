#pragma once
#include <iostream>
#include "Pair.h"

using namespace std;

class Tree
{
private:
	class Node
	{
	public:
		Pair value;
		Node* left;
		Node* right;
		Node* parent;
		Node(Pair value = Pair()); 
		Node(Pair value, Node* left, Node* right, Node* parent);
		~Node();
	};

	//Search
	Node* search_by_arg(Node* r, int arg) {
		if (!r || arg == r->value.get_arg()) return r;
		if (arg < r->value.get_arg()) return search_by_arg(r->left, arg);
		else return search_by_arg(r->right, arg);
	}
	Node* search_by_value(int value) {
		Iterator iter;
		for (iter = begin(); iter != end() && (*iter).get_value() != value; iter++);
		return iter.get_ptr();
	}


	bool isCorrect();
	void invert_tree();

protected:
	Node* root;
	static Node* next(Node*& r) {
		if (r->right) {
			return minimum(r->right);
		}

		Node* y = r->parent;
		while (y && r == y->right) {
			r = y;
			y = y->parent;
		}
		return y;
	}
	static Node* prev(Node*& r) {
		if (r->left) {
			return maximum(r->left);
		}

		Node* y = r->parent;
		while (y && r == y->left) {
			r = y;
			y = y->parent;
		}
		return y;
	}
	static Node*& minimum(Node*& r) {
		if (!r->left) {
			return r;
		}
		return minimum(r->left);
	}
	static Node*& maximum(Node*& r) {
		if (!r->right) {
			return r;
		}
		return maximum(r->right);
	}
public:
	Node*& getRoot() {
		return this->root;
	}
	class Iterator {
	public:
		friend class Tree;
		Node* ptr;
		Iterator() {
			this->ptr = nullptr;
		}
		Iterator(const Iterator& iter) {
			this->ptr = iter.ptr;
		}
		Iterator& operator=(const Iterator& iter) {
			this->ptr = iter.ptr;
			return *this;
		}
		Iterator operator++(int) {
			Iterator iter = *this;
			ptr = next(ptr);
			return iter;
		}
		Iterator& operator++() {
			ptr = next(ptr);
			return *this;
		}
		Iterator operator--(int) {
			Iterator iter = *this;
			ptr = prev(ptr);
			return iter;
		}
		Iterator& operator--() {
			ptr = prev(ptr);
			return *this;
		}
		Pair& operator*() {
			return ptr->value;
		}
		Pair* operator->() {
			return &(ptr->value);
		}
		Node* get_ptr() {
			return ptr;
		}
		bool operator!=(const Iterator& iter) {
			return (iter.ptr != ptr);
		}
		bool operator==(const Iterator& iter) {
			return (iter.ptr == ptr);
		}
	};

	Iterator begin() {
		Iterator it;
		it.ptr = minimum(this->root);
		return it;
	}
	Iterator end() {
		Iterator it;
		it.ptr = nullptr;
		return it;
	}

	Tree();
	Tree(const Tree& t);
	Tree(string& str);
	~Tree();

	void destroy_tree(Node* r);
	void copy_tree(Node* from, Node* s, Node* to);

	Tree& operator=(const Tree& t);

	void push(Node* r, Pair value);
	int getValue(int arg);
	//Access to elem
	Pair& at(int index);
	Tree get_invertable();

	Tree merge(Tree& t);
	Tree composition(Tree& t);

	void prefixTraverse(Node* r, ostream& os, bool flag = 1);
	//Relations
	bool operator==(Tree& t);
	bool operator!=(Tree& t);
	bool equal(Tree& t);
	//Arithmetic operations
	Tree operator+(Tree& t);
	Tree operator-(Tree& t);
	Tree operator*(Tree& t);
	Tree operator/(Tree& t);
	Tree operator%(Tree& t);

	//Stream I/O
	friend ostream& operator<<(ostream& os, Tree& t);
	friend istream& operator>>(istream& is, Tree& t);
};