#include <iostream>
#include "Pair.h"
#include "Tree.h"
#include "LexicalAnalyzer.h"
#include "SyntaxAnalyzer.h"
using namespace std;

int main(int argc, char* argv[]) {
	if (argc != 2)
	{
		cout << "File Error";
		return 1;
	}

	Parser p;
	p.parse(argv[1]);

	SyntaxAnalyzer sa;
//	sa.getTable();
//	sa.putTable();
	sa.getTableFromFile();
	sa.printTable();
	sa.parse(p.getLexemeList());

	return 0;
}