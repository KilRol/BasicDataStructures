#include "Tree.h"

Tree::Node::Node(Pair value)
{
	this->value = value;
	this->left = nullptr;
	this->right = nullptr;
	this->parent = nullptr;
}

Tree::Node::Node(Pair value, Node* left, Node* right, Node* parent)
{
	this->value = value;
	this->left = left;
	this->right = right;
	this->parent = parent;
}

Tree::Node::~Node()
{
	delete left;
	delete right;
}

bool Tree::isCorrect()
{
	for (Iterator iter1 = begin(); iter1 != end(); iter1++) {
		int count = 0;
		for (Iterator iter2 = iter1; iter2 != end(); iter2++) {
			if (iter1->get_arg() == iter2->get_arg()) count++;
		}
		if (count > 1) return false;
	}
	return true;
}

void Tree::invert_tree()
{
	for (Iterator iter = begin(); iter != end(); iter++)
		iter->invert_pair();
}

Tree::Tree()
{
	root = nullptr;
}

Tree::Tree(const Tree& t)
{
	if (!t.root) root = nullptr;
	else {
		root = new Node(t.root->value);
		if (t.root->left) {
			root->left = new Node(t.root->left->value);
			copy_tree(root, t.root->left, root->left);
		}
		if (t.root->right) {
			root->right = new Node(t.root->right->value);
			copy_tree(root, t.root->right, root->right);
		}
	}
}

Tree::Tree(string& str)
{
	root = nullptr;
	if (str[1] == '}') return;
	for (int i = 1; str[i]; i++)
	{
		int arg = 0;
		int val = 0;

		for (i; str[i] != '>'; i++) {
			arg = 10 * arg + str[i] - '0';
		}
		i++;
		for (i; str[i] != ',' && str[i] != '}'; i++)
			val = 10 * val + str[i] - '0';
		push(getRoot(), Pair(arg, val));
	}
}

Tree::~Tree()
{
	delete root;
}

void Tree::destroy_tree(Node* r)
{
	delete root;
	root = nullptr;
}

void Tree::copy_tree(Node* from, Node* s, Node* to)
{
	if (s->left) to->left = new Node(s->left->value);
	if (s->right) to->right = new Node(s->right->value);
	to->parent = from;
	if (to->left) copy_tree(to, s->left, to->left);
	if (to->right) copy_tree(to, s->right, to->right);
}

Tree& Tree::operator=(const Tree& t)
{
	if (this == &t) return *this;
	destroy_tree(root);
	if (!t.root) root = nullptr;
	else {
		root = new Node(t.root->value);
		if (t.root->left) {
			root->left = new Node(t.root->left->value);
			copy_tree(root, t.root->left, root->left);
		}
		if (t.root->right) {
			root->right = new Node(t.root->right->value);
			copy_tree(root, t.root->right, root->right);
		}
	}
	return *this;
}

void Tree::push(Node* r, Pair value)
{
	Node* nd = new Node(value);
	if (!r) {
		this->root = nd;
		return;
	}
	try {
		while (r) {
			if (nd->value > root->value) {
				if (r->right) {
					r = r->right;
				}
				else {
					nd->parent = r;
					r->right = nd;
					break;
				}
			}
			else if (nd->value < root->value) {
				if (r->left) {
					r = r->left;
				}
				else {
					nd->parent = r;
					r->left = nd;
					break;
				}
			}
			else {
				if (nd->value.get_value() != r->value.get_value())
					throw "Push Error! Equal arg and different value";
				break;
			}
		}
	}
	catch (const char* e) {
		cout << e << endl;
		destroy_tree(root);
	}
}

int Tree::getValue(int arg)
{
	return search_by_arg(root, arg)->value.get_value();
}

Pair& Tree::at(int index)
{
	Iterator iter = begin();
	int i = 0;
	for (i; i < index && iter != end(); i++, iter++);
	if (i == index) {
		return *iter;
	}
}

Tree Tree::get_invertable()
{
	Tree newTree = *this;
	Tree result_tree;
	if (newTree.root) {
		newTree.invert_tree();
		if (newTree.isCorrect()) {
			for (Iterator iter = newTree.begin(); iter != newTree.end(); iter++)
				result_tree.push(result_tree.root, *iter);
		}
		else {
			cout << "Invertable mapping doesn't exist" << endl;
		}
	}
	return result_tree;
}

Tree Tree::merge(Tree& t)
{
	Tree tree;
	Iterator iter1 = begin();
	Iterator iter2 = t.begin();
	try {
		while (iter1 != end() && iter2 != t.end()) {
			if ((*iter1) < (*iter2)) {
				tree.push(tree.getRoot(), *(iter1++));
			}
			else if ((*iter1) > (*iter2)) {
				tree.push(tree.getRoot(), *(iter2++));
			}
			else {
				if (iter1->get_value() == iter2->get_value()) {
					tree.push(tree.getRoot(), *(iter1++));
					iter2++;
				}
				else throw "Merge Error! Equal arg and different value";
			}
		}
		while (iter1 != end()) {
			tree.push(tree.getRoot(), *(iter1++));
		}
		while (iter2 != t.end()) {
			tree.push(tree.getRoot(), *(iter2++));
		}
	}
	catch (const char* e) {
		cout << e << endl;
		tree.destroy_tree(tree.root);
		return tree;
	}
	return tree;
}

Tree Tree::composition(Tree& t)
{
	Tree tree;
	Iterator iter = t.begin();
	while (iter != t.end()) {
		if (search_by_arg(root, iter->get_value())) {
			int a = iter->get_arg();
			int b = search_by_arg(root, iter->get_value())->value.get_value();
			tree.push(tree.getRoot(), Pair(a, b));
		}
		iter++;
	}
	return tree;
}

void Tree::prefixTraverse(Node* r, ostream& os, bool flag)
{
	if (r) {
		if (flag) os << r->value;
		else os << ", " << r->value;
		prefixTraverse(r->left, os, 0);
		prefixTraverse(r->right, os, 0);
	}
}

bool Tree::operator==(Tree& t)
{
	Iterator iter1 = begin();
	Iterator iter2 = t.begin();
	while (iter1 != end() && iter2 != t.end()) {
		if ((*iter1++) != (*iter2++)) return false;
	}
	if (iter1 != end() || iter2 != t.end()) return false;
	return true;
}

bool Tree::operator!=(Tree& t)
{
	return !(*this == t);
}

bool Tree::equal(Tree& t)
{
	Iterator iter1 = begin();
	Iterator iter2 = t.begin();
	while (iter1 != end() && iter2 != t.end()) {
		if (!(*iter1++).equal(*iter2++)) return false;
	}
	if (iter1 != end() || iter2 != t.end()) return false;
	return true;
}

Tree Tree::operator+(Tree& t)
{
	Tree result_tree;
	Iterator iter = begin();
	for (iter; iter != end(); iter++)
	{
		Pair h = (*iter);
		try {
			if (t.search_by_arg(t.root, iter->get_arg())) {
				h += t.search_by_arg(t.root, iter->get_arg())->value;
				result_tree.push(result_tree.getRoot(), h);
			}
			else throw "Result not defined";
		}
		catch (const char* e) {
			cout << "For elem " << h << " defined only one mapping. " << e << endl;
		}
	}
	return result_tree;
}

Tree Tree::operator-(Tree& t)
{
	Tree result_tree;
	Iterator iter = begin();
	for (iter; iter != end(); iter++)
	{
		Pair h = (*iter);
		try {
			if (t.search_by_arg(t.root, iter->get_arg())) {
				h -= t.search_by_arg(t.root, iter->get_arg())->value;
				result_tree.push(result_tree.getRoot(), h);
			}
			else throw "Result not defined";
		}
		catch (const char* e) {
			cout << "For elem " << h << " defined only one mapping. " << e << endl;
		}
	}
	return result_tree;
}

Tree Tree::operator*(Tree& t)
{
	Tree result_tree;
	Iterator iter = begin();
	for (iter; iter != end(); iter++)
	{
		Pair h = (*iter);
		try {
			if (t.search_by_arg(t.root, iter->get_arg())) {
				h *= t.search_by_arg(t.root, iter->get_arg())->value;
				result_tree.push(result_tree.getRoot(), h);
			}
			else throw "Result not defined";
		}
		catch (const char* e) {
			cout << "For elem " << h << " defined only one mapping. " << e << endl;
		}
	}
	return result_tree;
}

Tree Tree::operator/(Tree& t)
{
	Tree result_tree;
	Iterator iter = begin();
	for (iter; iter != end(); iter++)
	{
		Pair h = (*iter);
		try {
			if (t.search_by_arg(t.root, iter->get_arg())) {
				h /= t.search_by_arg(t.root, iter->get_arg())->value;
				result_tree.push(result_tree.getRoot(), h);
			}
			else throw "Result not defined";
		}
		catch (const char* e) {
			cout << "For elem " << h << " defined only one mapping. " << e << endl;
		}
	}
	return result_tree;
}

Tree Tree::operator%(Tree& t)
{
	Tree result_tree;
	Iterator iter = begin();
	for (iter; iter != end(); iter++)
	{
		Pair h = (*iter);
		try {
			if (t.search_by_arg(t.root, iter->get_arg())) {
				h %= t.search_by_arg(t.root, iter->get_arg())->value;
				result_tree.push(result_tree.getRoot(), h);
			}
			else throw "Result not defined";
		}
		catch (const char* e) {
			cout << "For elem " << h << " defined only one mapping. " << e << endl;
		}
	}
	return result_tree;
}

ostream& operator<<(ostream& os, Tree& t)
{
	os << '{';
	t.prefixTraverse(t.getRoot(), os);
	os << '}';
	return os;
}

istream& operator>>(istream& is, Tree& t)
{
	t.destroy_tree(t.getRoot());
	try
	{
		Pair a;
		char b;
		is >> b;
		if (b != '{') throw "Incorrect Input";
		do {
			is >> a;
			t.push(t.getRoot(), a);
			is >> b;
		} while (b != '}');
	}
	catch (const char* e)
	{
		is.clear();
		cout << e << endl;
	}
	return is;
}