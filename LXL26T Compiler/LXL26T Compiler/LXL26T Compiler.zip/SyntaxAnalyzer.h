#include <map>
#include <string>
#include <set>
#include <stack>
#include <list>
#include <iostream>
#include <vector>
#include <ctime>
#include "LexicalAnalyzer.h"
#include <fstream>
using namespace std;

class SyntaxAnalyzer
{
private:
	ofstream log;

	class Production {
	public:
		string name;
		Production() : name("") {}
		Production(string n) : name(n) {}
		string getName() const {
			return name;
		}
		bool operator<(Production* p) const {
			return name < p->name;
		}
		bool operator==(const Production* p) const {
			return name == p->name;
		}
		virtual int getType() = 0;
		friend ostream& operator<<(ostream& os, const Production* p) {
			return os << p->name;
		}
	};
	class Terminal : virtual public Production {
	public:
		Terminal() : Production() {}
		Terminal(string n) : Production(n) {}
		bool operator<(const Terminal& t) const {
			return name < t.name;
		}
		bool operator==(const Terminal& t) const {
			return name == t.name;
		}
		bool operator==(const Production* p) const {
			return name == p->name;
		}
		int getType() {
			return 0;
		}
		friend ostream& operator<<(ostream& os, const Terminal& t) {
			return os << t.getName();
		}
	};
	class NonTerminal : virtual public Production {
	public:
		NonTerminal() : Production() {}
		NonTerminal(string n) : Production(n) {}
		bool operator<(const NonTerminal& nt) const {
			return name < nt.name;
		}
		bool operator==(const NonTerminal& nt) const {
			return name == nt.name;
		}
		bool operator==(const Production* p) const {
			return name == p->name;
		}
		int getType() {
			return 1;
		}
		friend ostream& operator<<(ostream& os, const NonTerminal& nt) {
			return os << nt.getName();
		}
	};
	class Item {
	private:
		NonTerminal nonTerminal;
		vector<Production*> production;
		Terminal lookahead;
		int position;
	public:
		Item() : position(0) {}
		Item(NonTerminal nt, vector<Production*> prod, Terminal la = Terminal("$"), int pos = 0)
			: nonTerminal(nt), production(prod), lookahead(la), position(pos) {}
		bool operator==(const Item& item) const {
			return nonTerminal == item.nonTerminal && production == item.production && lookahead == item.lookahead && position == item.position;
		}
		bool operator<(const Item& item) const {
			return nonTerminal < item.nonTerminal&& production < item.production&& lookahead < item.lookahead&& position < item.position;
		}
		void incrPosition() {
			position++;
		}
		NonTerminal getNonTerminal() {
			return nonTerminal;
		}
		vector<Production*> getProduction() {
			return production;
		}
		Terminal getLookahead() {
			return lookahead;
		}
		int getPosition() {
			return position;
		}
		friend ostream& operator<<(ostream& os, Item& item) {
			os << item.nonTerminal << "->";
			for (int i = 0; i < item.production.size(); i++) {
				if (i == item.getPosition()) {
					os << ".";
				}
				os << item.production[i];
			}
			return os << "; " << item.lookahead;
		}
	};

	vector<Terminal> FIRST(Item item) {
		vector<Terminal> firstList;
		stack<NonTerminal> st;
		Production* f = item.getProduction()[0];
		if (f->getType() == 0) {
			firstList.push_back(Terminal(f->getName()));
			return firstList;
		}
		st.push(NonTerminal(f->getName()));

		while (!st.empty()) {
			NonTerminal tmp = st.top();
			st.pop();
			for (int i = 0; i < rules.size(); i++) {
				if (tmp == rules[i].getNonTerminal()) {
					Production* p = rules[i].getProduction()[0];
					if (p->getType() == 0) {
						firstList.push_back(Terminal(p->getName()));
					}
					else if (p->getName() == tmp.getName()) {
						continue;
					}
					else {
						st.push(NonTerminal(p->getName()));
					}

				}
			}
		}
		return firstList;
	}

	map<NonTerminal, set<Terminal>> firstAll;
	void setFirstAll() {
		for (auto r : rules) {
			for (auto p : FIRST(r)) {
				firstAll[r.getNonTerminal()].insert(p);
			}
		}
	}

	vector<Item> rules;
	vector<vector<Item>> tables;
	vector<vector<Item>> GOTOAll;
	vector<vector<Item>> CLOSUREAll;
	vector<Terminal>  termList;
	map<Production* , map<vector<Item>, int>> tableForAction;

	bool checkTable(vector<Item> v, Item item) {
		for (int i = 0; i < v.size(); i++) {
			if (v[i] == item) {
				return 0;
			}
		}
		return 1;
	}

	void optCLOSURE(vector<Item> v) {
		vector<Item> closureV(v);
		for (int i = 0; i < closureV.size(); i++) {
			for (int j = 0; j < rules.size(); j++) {
				vector<Terminal> firstList;
				if (closureV[i].getPosition() < closureV[i].getProduction().size()) {
					if (rules[j].getNonTerminal() == closureV[i].getProduction()[closureV[i].getPosition()]) {
						if (closureV[i].getPosition() + 1 < closureV[i].getProduction().size()) {
							if (closureV[i].getProduction()[closureV[i].getPosition() + 1]->getType() == 0) {
								firstList.push_back(Terminal(closureV[i].getProduction()[closureV[i].getPosition() + 1]->getName()));
							}
							else {
								NonTerminal nt(closureV[i].getProduction()[closureV[i].getPosition() + 1]->getName());
								for (auto d : firstAll[nt]) {
									firstList.push_back(d);
								}
							}
							for (int k = 0; k < firstList.size(); k++) {
								Item t(rules[j].getNonTerminal(), rules[j].getProduction(), firstList[k]);
								if (checkTable(closureV, t)) {
									closureV.push_back(t);
								}
							}
						}
						else {
							Item t(rules[j].getNonTerminal(), rules[j].getProduction(), closureV[i].getLookahead());
							if (checkTable(closureV, t)) {
								closureV.push_back(t);
							}
						}
					}
				}
			}
		}
		CLOSUREAll.push_back(closureV);

	}

	int optGOTO(vector<Item> v, Production* p, bool calcClosure) {
		vector<Item> res;
		for (int i = 0; i < v.size(); i++) {
			if (v[i].getPosition() < v[i].getProduction().size()) {
				if (v[i].getProduction()[v[i].getPosition()]->getName() == p->getName()) {
					Item tmp(v[i]);
					tmp.incrPosition();
					res.push_back(tmp);
				}
			}
		}
		if (!res.empty()) {
			for (int i = 0; i < GOTOAll.size(); i++) {
				if (GOTOAll[i] == res) return i;
			}
			if (calcClosure) {
				GOTOAll.push_back(res);
				optCLOSURE(res);
			}
		}
		return -1;
	}

	void optItems() {
		GOTOAll.push_back({ rules.front() });
		optCLOSURE({ rules.front() });

		for (int i = 0; i < CLOSUREAll.size(); i++) {
			for (int j = 0; j < rules.size(); j++) {
				optGOTO(CLOSUREAll[i], new NonTerminal(rules[j].getNonTerminal()), true);
			}
			for (int j = 0; j < termList.size(); j++) {
				optGOTO(CLOSUREAll[i], &termList[j], true);
			}

		}
	}

	struct Act {
		string action;
		int rule;
		Act() : action(""), rule(-1) {}
		Act(string act, int r = -1) : action(act), rule(r) {}
		bool operator==(const Act& a) const {
			return action == a.action && rule == a.rule;
		}
		friend ostream& operator<<(ostream& os, Act& a) {
			return os << a.action << a.rule;
		}
	};

	map<int, map<Terminal, Act>> actionTable;

	int findTable(vector<Item> v) {
		for (int i = 0; i < tables.size(); i++) {
			if (tables[i].size() != v.size()) continue;
			if (tables[i] == v) return i;
		}
		return -1;
	}

	int getRule(Item nt) {
		for (int i = 0; i < rules.size(); i++) {
			if (rules[i].getNonTerminal() == nt.getNonTerminal() && rules[i].getProduction() == nt.getProduction())
				return i;
		}
	}

	void optGetActionTable() {
		for (int i = 0; i < CLOSUREAll.size(); i++) {
			clock_t a, b, c, d;
			a = clock();
			for (int j = 0; j < CLOSUREAll[i].size(); j++) {
				if (CLOSUREAll[i][j].getPosition() < CLOSUREAll[i][j].getProduction().size()) {
					bool flag = 0;
					c = clock();
					for (Terminal term : termList) {
						int point = optGOTO(CLOSUREAll[i], &term, false);
						if (point != -1) {
							if (actionTable[i][term] == Act() || actionTable[i][term] == Act("s", point)) {
								actionTable[i][term] = Act("s", point);
							}
							else {
								cout << "CONFLICT:" << "I" << i << ", " << term << endl;
							}
						}
					}
					d = clock();
					cout << "I" << i << " " << j << " " << (d - c) << "ms" << endl;
				}
				else if (CLOSUREAll[i][j].getPosition() == CLOSUREAll[i][j].getProduction().size()) {
					int rule = getRule(CLOSUREAll[i][j]);
					if (actionTable[i][CLOSUREAll[i][j].getLookahead()] == Act() || actionTable[i][CLOSUREAll[i][j].getLookahead()] == Act("r", rule))
						actionTable[i][CLOSUREAll[i][j].getLookahead()] = Act("r", rule);
					else {
						cout << "GOTO CONFLICT:" << "I" << i << endl;
						cout << "ATTEMPT TO ASSIGN RULE " << rule;
					}
				}
			}
			b = clock();
			cout << endl << "T" << i << " " << (b - a) / 1000 << "s" << endl << endl;
		}
	}

	struct Step {
		int rule;
		Step() : rule(-1) {}
		Step(int r) : rule(r) {}
		bool operator==(const Step& s) const {
			return rule == s.rule;
		}
		friend ostream& operator<<(ostream& os, const Step& s) {
			return os << s.rule;
		}
	};

	map<int, map<NonTerminal, Step>> gotoTable;
	set<NonTerminal> nonTermList;

	void optGetGotoTable() {
		for (int i = 0; i < CLOSUREAll.size(); i++) {
			for (int j = 0; j < CLOSUREAll[i].size(); j++) {
				if (CLOSUREAll[i][j].getPosition() < CLOSUREAll[i][j].getProduction().size()) {
					for (NonTerminal nt : nonTermList) {
						int point = optGOTO(CLOSUREAll[i], &nt, false);
						if (point != -1) {
							if (gotoTable[i][nt] == Step() || gotoTable[i][nt] == Step(point)) {
								gotoTable[i][nt] = Step(point);
							}
							else {
								cout << "CONFLICT" << endl;
							}
						}
					}
					break;
				}
			}
		}
	}

	void getCanonicalTable() {

		clock_t a, b;

		a = clock();
		optItems();
		b = clock();

		cout << endl << "TABLES COMPLETE " << (b - a) / 1000 << "s." << endl;
		cout << GOTOAll.size() << " tables" << endl;

		a = clock();
		optGetActionTable();
		b = clock();

		for (auto t : tableForAction) {
			cout << t.first << endl;
			for (auto r : t.second) {
				cout << "GOTO" << endl;
				for (auto g : r.first) {
					cout << g << endl;
				}
				cout << "ENDGOTO" << endl;
				cout << r.second << endl;
			}

			cout << endl << endl;;
		}

		cout << endl << "ACTION TABLE COMPLETE " << (b - a) / 1000 << "s." << endl;

		a = clock();
		optGetGotoTable();
		b = clock();

		cout << endl << "GOTO TABLE COMPLETE " << (b - a) / 1000 << "s." << endl;

		cout << endl;
		cout << "---%TABLES%---" << endl;
		int iee = 0;
		for (auto t : tables) {
			cout << "I" << iee++ << endl;
			for (auto r : t) {
				cout << r << endl;
			}
			cout << endl;
		}
		cout << "CANONICAL ACTION TABLE" << endl;

		for (auto t : actionTable) {
			cout << t.first << " ";
			for (auto r : t.second) {
				cout << r.first << "->" << r.second << " ";
			}
			cout << endl;
		}

		cout << endl;
		cout << "CANONICAL GOTO TABLE" << endl;

		for (auto t : gotoTable) {
			cout << t.first << " ";
			for (auto r : t.second) {
				cout << r.first << "->" << r.second << " ";
			}
			cout << endl;
		}
		cout << endl;
	}

	void analyze(vector<Terminal> buf) {
		list<int> state;

		cout << "input:\t";

		for (auto t : buf) {
			cout << t << " ";
		}
		cout << endl << endl;

		state.push_back(0);
		for (int i = 0; i < buf.size();) {
			if (actionTable[state.back()][buf[i]].action == "s") {
				state.push_back(actionTable[state.back()][buf[i]].rule);
				cout << "shift:\t" << buf[i] << endl;
				i++;
			}
			else if (actionTable[state.back()][buf[i]].action == "r" && actionTable[state.back()][buf[i]].rule != 0) {
				int rule = actionTable[state.back()][buf[i]].rule;
				int count = rules[actionTable[state.back()][buf[i]].rule].getProduction().size();
				NonTerminal nt = rules[actionTable[state.back()][buf[i]].rule].getNonTerminal();
				for (int j = 0; j < count; j++) {
					state.pop_back();
				}
				state.push_back(gotoTable[state.back()][nt].rule);
				cout << "reduce:\t" << rules[rule] << endl;
			}
			else if (actionTable[state.back()][buf[i]].rule == 0) {
				cout << endl << "Success" << endl;
				break;
			}
			else {
				cout << "ERROR " << state.back() << " " << buf[i] << endl;
				exit(-1);
			}
			cout << "Magazine: ";
			for (auto p : state) {
				cout << p << " ";
			}
			cout << endl << endl;
		}
	}

	vector<Terminal> buf;

	bool checkTermVector(Production* t) {
		for (auto p : termList) {
			if (t == &p) return 0;
		}
		return 1;
	}

public:
	SyntaxAnalyzer() {

		log.open("log.txt");

		rules = {
			Item(NonTerminal("S"), { new NonTerminal("<program>") }),
			Item(NonTerminal("<program>"), { new NonTerminal("<operator>"), new NonTerminal("<program>") }),
			Item(NonTerminal("<program>"), { new NonTerminal("<operator>") }),
			Item(NonTerminal("<operator>"), { new Terminal("DECLARE"), new Terminal("VARIABLE"), new NonTerminal("<type>"), new NonTerminal("<declare_list>"), new Terminal("SEMICOLON")}),
			Item(NonTerminal("<operator>"), { new Terminal("DECLARE"), new Terminal("VARIABLE"), new NonTerminal("<type>"), new Terminal("SEMICOLON")}),
			Item(NonTerminal("<declare_list>"), { new Terminal("COMMA"), new Terminal("VARIABLE"), new NonTerminal("<type>"), new NonTerminal("<declare_list>")}),
			Item(NonTerminal("<declare_list>"), { new Terminal("COMMA"), new Terminal("VARIABLE"), new NonTerminal("<type>")}),
			Item(NonTerminal("<operator>"), { new Terminal("SET"), new Terminal("VARIABLE"), new NonTerminal("<set_list>"), new Terminal("TO") , new NonTerminal("<exp>"), new Terminal("SEMICOLON")}),
			Item(NonTerminal("<operator>"), { new Terminal("SET"), new Terminal("VARIABLE"), new Terminal("TO") , new NonTerminal("<exp>"), new Terminal("SEMICOLON")}),
			Item(NonTerminal("<set_list>"), { new Terminal("COMMA"), new Terminal("VARIABLE"), new NonTerminal("<set_list>")}),
			Item(NonTerminal("<set_list>"), {  new Terminal("COMMA"), new Terminal("VARIABLE")}),
			//Item(NonTerminal("<operator>"), { new Terminal("WHILE"), new NonTerminal("<test>"), new Terminal("DO"), new NonTerminal("<operator>")}),
			//Item(NonTerminal("<test>"), { new NonTerminal("<exp>"), new Terminal("RELATION"), new NonTerminal("<exp>") }),
			//Item(NonTerminal("<operator>"), { new Terminal("FOR"), new Terminal("VARIABLE"), new Terminal("ASSIGNMENT"), new NonTerminal("<exp>"), new Terminal("TO"),  new NonTerminal("<exp>"), new Terminal("DO"), new NonTerminal("<operator>") }),
			//Item(NonTerminal("<operator>"), { new Terminal("IF"), new NonTerminal("<test>"), new Terminal("THEN"), new NonTerminal("<operator>") }),
			//Item(NonTerminal("<operator>"), { new Terminal("IF"), new NonTerminal("<test>"), new Terminal("THEN"), new NonTerminal("<operator>"), new NonTerminal("<else>"), new NonTerminal("<operator>")}),
			//Item(NonTerminal("<operator>"), { new Terminal("BEGIN"),new NonTerminal("<program>"), new Terminal("END")}),
			Item(NonTerminal("<operator>"), { new Terminal("BAD"), new Terminal("SEMICOLON")}),
			Item(NonTerminal("<operator>"), { new Terminal("COMMENT")}),
			//Item(NonTerminal("<operator>"), { new NonTerminal("<cin_list>"), new Terminal("CIN"), new Terminal("SEMICOLON")}),
			//Item(NonTerminal("<cin_list>"), { new Terminal("VARIABLE"), new Terminal("ARROW_LEFT"), new Terminal("<cin_list>")}),
			//Item(NonTerminal("<cin_list>"), { new Terminal("VARIABLE"), new Terminal("ARROW_LEFT")}),
			//Item(NonTerminal("<operator>"), { new NonTerminal("<cout_list>"), new Terminal("COUT"), new Terminal("SEMICOLON")}),
			//Item(NonTerminal("<cout_list>"), { new NonTerminal("<exp>"), new Terminal("ARROW_RIGHT"), new NonTerminal("<cout_list>")}),
			//Item(NonTerminal("<cout_list>"), { new NonTerminal("<exp>"), new Terminal("ARROW_RIGHT")}),
			//Item(NonTerminal("<operator>"), { new Terminal("SWITCH"),  new Terminal("OPEN_BRACKET"), new NonTerminal("<exp>"), new Terminal("CLOSED_BRACKET"), new NonTerminal("<case_list>"),  new NonTerminal("<default>"), new Terminal("END"), new Terminal("SWITCH"), new Terminal("SEMICOLON"), }),
			//Item(NonTerminal("<operator>"), { new Terminal("SWITCH"),  new Terminal("OPEN_BRACKET"), new NonTerminal("<exp>"), new Terminal("CLOSED_BRACKET"), new NonTerminal("<case_list>"), new Terminal("END"), new Terminal("SWITCH"), new Terminal("SEMICOLON"), }),
			//Item(NonTerminal("<default>"), {new Terminal("DEFAULT"),  new Terminal("COLON"), new NonTerminal("<operator>")}),
			//Item(NonTerminal("<case_list>"), { new Terminal("CASE"), new Terminal("CONST"), new NonTerminal("<const_list>"), new Terminal("COLON"), new NonTerminal("<operator>"), new NonTerminal("<case_list>")}),
			//Item(NonTerminal("<case_list>"), { new Terminal("CASE"), new Terminal("CONST"), new NonTerminal("<const_list>"), new Terminal("COLON"), new NonTerminal("<operator>")}),
			//Item(NonTerminal("<case_list>"), { new Terminal("CASE"), new Terminal("CONST"), new Terminal("COLON"), new NonTerminal("<operator>"), new NonTerminal("<case_list>")}),
			//Item(NonTerminal("<case_list>"), { new Terminal("CASE"), new Terminal("CONST"), new Terminal("COLON"), new NonTerminal("<operator>")}),
			//Item(NonTerminal("<const_list>"), {new NonTerminal("<const_el>"), new NonTerminal("<const_list>")}),
			//Item(NonTerminal("<const_list>"), {new NonTerminal("<const_el>")}),
			//Item(NonTerminal("<const_el>"), { new Terminal("COMMA"), new Terminal("CONST")}),
			//Item(NonTerminal("<operator>"), { new Terminal("SEMICOLON")}),
			//Item(NonTerminal("<operator>"), { new Terminal("MARK")}),
			//Item(NonTerminal("<operator>"), { new Terminal("JUMP"), new Terminal("SEMICOLON")}),
			Item(NonTerminal("<exp>"), { new NonTerminal("<exp>"), new Terminal("ADD"), new NonTerminal("<T>")}),
			Item(NonTerminal("<exp>"), { new NonTerminal("<exp>"), new Terminal("SUBT"), new NonTerminal("<T>")}),
			Item(NonTerminal("<exp>"), { new NonTerminal("<T>") }),
			Item(NonTerminal("<T>"), { new NonTerminal("<T>"), new Terminal("MULT"), new NonTerminal("<F>") }),
			Item(NonTerminal("<T>"), { new NonTerminal("<T>"), new Terminal("DIV"), new NonTerminal("<F>") }),
			Item(NonTerminal("<T>"), { new NonTerminal("<T>"), new Terminal("MOD"), new NonTerminal("<F>") }),
			Item(NonTerminal("<T>"), { new NonTerminal("<F>") }),
			Item(NonTerminal("<F>"), { new Terminal("VARIABLE") }),
			Item(NonTerminal("<F>"), { new Terminal("CONST") }),
			//Item(NonTerminal("<F>"), { new Terminal("FIND"), new Terminal("OPEN_BRACKET"), new NonTerminal("<exp>"), new Terminal("COMMA"), new NonTerminal("<exp>"), new Terminal("CLOSED_BRACKET") }),
			//Item(NonTerminal("<F>"), { new Terminal("COMPOSITION"), new Terminal("OPEN_BRACKET"), new NonTerminal("<exp>"), new Terminal("COMMA"), new NonTerminal("<exp>"), new Terminal("CLOSED_BRACKET") }),
			//Item(NonTerminal("<F>"), { new Terminal("MERGE"), new Terminal("OPEN_BRACKET"), new NonTerminal("<exp>"), new Terminal("COMMA"), new NonTerminal("<exp>"), new Terminal("CLOSED_BRACKET") }),
			//Item(NonTerminal("<F>"), { new Terminal("AT"), new Terminal("OPEN_BRACKET"), new NonTerminal("<exp>"), new Terminal("COMMA"), new NonTerminal("<exp>"), new Terminal("CLOSED_BRACKET") }),
			//Item(NonTerminal("<F>"), { new Terminal("INVERT"), new Terminal("OPEN_BRACKET"), new NonTerminal("<exp>"), new Terminal("CLOSED_BRACKET") }),
			//Item(NonTerminal("<F>"), { new Terminal("OPEN_BRACKET") , new NonTerminal("<exp>"), new Terminal("CLOSED_BRACKET")  }),
			Item(NonTerminal("<type>"), { new Terminal("INT") }),
			Item(NonTerminal("<type>"), { new Terminal("TREE") }),

			Item(NonTerminal("S'"), { new NonTerminal("S") }),
			Item(NonTerminal("S"), { new NonTerminal("C"), new NonTerminal("C") }),
			Item(NonTerminal("C"), { new Terminal("c"), new NonTerminal("C") }),
			Item(NonTerminal("C"), { new Terminal("d") }),

			/*Item(NonTerminal("E"), {new NonTerminal("E"), new Terminal("ADD"), new NonTerminal("T")} ),
			Item(NonTerminal("E"), {new NonTerminal("T")} ),
			Item(NonTerminal("T"), {new NonTerminal("F")} ),
			Item(NonTerminal("F"), {new Terminal("VARIABLE")} ),
			Item(NonTerminal("F"), {new Terminal("CONST")} ),*/

		};

		cout << "---%RULES%---" << endl;
		for (int i = 0; i < rules.size(); i++) {
			cout << i << " " << rules[i].getNonTerminal() << "->";
			for (auto p : rules[i].getProduction()) {
				cout << p;
			}
			cout << endl;
		}
		cout << endl;

		for (auto r : rules) {
			for (auto p : r.getProduction()) {
				if (p->getType() == 0) {
					if (checkTermVector(p)) termList.push_back(Terminal(p->getName()));
				}
			}
		}

		for (auto r : rules) {
			nonTermList.insert(r.getNonTerminal());
		}

		setFirstAll();
		cout << endl << "ALL FIRST" << endl;
		for (auto t : firstAll) {
			cout << t.first << ": ";
			for (auto r : t.second) {
				cout << r << " ";
			}
			cout << endl;
		}

		//vector<Terminal> buf = { Terminal("c"), Terminal("d"), Terminal("d"), Terminal("$") };
		//analyze(buf);
	}

	void getTable() {
		getCanonicalTable();
	}

	void parse(vector<LexemeToken> lexemeList) {
		vector<Terminal> buf;
		for (auto l : lexemeList) {
			if (l.lexeme == Lexeme::ARITHMET) {
				switch (*(int*)l.value) {
				case 43: buf.push_back(Terminal("ADD")); break;
				case 45: buf.push_back(Terminal("SUBT")); break;
				case 42: buf.push_back(Terminal("MULT")); break;
				case 47: buf.push_back(Terminal("DIV")); break;
				case 37: buf.push_back(Terminal("MOD")); break;
				}
			}
			else if (l.lexeme == Lexeme::ENDMARK) { 
				buf.push_back(Terminal("$"));
			}
			else {
				buf.push_back(Terminal(LexemeTokenClassName[(int)l.lexeme]));
			}
		}
		analyze(buf);
	}

	void putTable() {
		ofstream out("canonicalTable.txt");

		for (auto t : actionTable) {
			out << t.first << endl;
			for (auto r : t.second) {
				out << r.first << " " << r.second.action << " " << r.second.rule << " ";
			}
			out << ";" << endl;
		}

		out << "-1" << endl;

		for (auto t : gotoTable) {
			out << t.first << endl;
			for (auto r : t.second) {
				out << r.first << " " << r.second << " ";
			}
			out << ";" << endl;
		}
		out << "-2" << endl;
	}

	void getTableFromFile() {
		ifstream in("canonicalTable.txt");
		int q;
		while (1) {
			in >> q;
			if (q == -1) break;
			string T;
			string A;
			int R;
			while (1) {
				in >> T;
				if (T == ";") break;
				in >> A;
				in >> R;
				actionTable[q][Terminal(T)] = Act(A, R);
			}
		}
		while (1) {
			in >> q;
			if (q == -2) break;
			string T;
			int R;
			while (1) {
				in >> T;
				if (T == ";") break;
				in >> R;
				gotoTable[q][NonTerminal(T)] = Step(R);
			}
		}
	}

	void printTable() {
		cout << "CANONICAL ACTION TABLE" << endl;

		for (auto t : actionTable) {
			cout << t.first << " ";
			for (auto r : t.second) {
				cout << r.first << "->" << r.second << " ";
			}
			cout << endl;
		}

		cout << endl;
		cout << "CANONICAL GOTO TABLE" << endl;

		for (auto t : gotoTable) {
			cout << t.first << " ";
			for (auto r : t.second) {
				cout << r.first << "->" << r.second << " ";
			}
			cout << endl;
		}
		cout << endl;
	}

};