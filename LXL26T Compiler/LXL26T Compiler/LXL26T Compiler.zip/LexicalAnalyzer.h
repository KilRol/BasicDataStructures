#pragma once
#include <iostream>
#include "Tree.h"
#include <vector>
#include <string>
#include <fstream>
#include "Variable.h"
#include <map>
using namespace std;

enum class LexemeTokenClass { AT, COMPOSITION, FIND, INVERT, MERGE, ARROW_LEFT, ARROW_RIGHT, INT, TREE, CONST, VARIABLE, ARITHMET, RELATION, ASSIGNMENT, DECLARE, SET, WHILE, DO, FOR, TO, IF, THEN, ELSE, CIN, COUT, MARK, JUMP, SWITCH, CASE, DEFAULT, BAD, BEGIN, END, COMMENT, SEMICOLON, COMMA, OPEN_BRACKET, CLOSED_BRACKET, COLON, ERROR, ENDMARK, END_OF_FILE };
enum class SymbolicTokenClass { Letter, Digit, Arithmet, Relation, Space, LF, Semicolon, Colon, OpenCurveBracket, ClosedCurveBracket, OpenBracket, ClosedBracket, Comma, Error, EndOfFile };
enum class State { A1, B1, C1, C2, C3, C4, D1, E1, E2, E3, F1, F2, F3, G1, G2, G3, G4, H1, I1, I2, J1, K1, K2, K3, K4, Exit };

const string LexemeTokenClassName[50] = { "AT", "COMPOSITION", "FIND", "INVERT", "MERGE","ARROW_LEFT", "ARROW_RIGHT", "INT", "TREE", "CONST", "VARIABLE", "ARITHMET", "RELATION", "ASSIGNMENT", "DECLARE", "SET", "WHILE", "DO", "FOR", "TO", "IF", "THEN", "ELSE", "CIN", "COUT", "MARK", "JUMP", "SWITCH", "CASE", "DEFAULT", "BAD", "BEGIN", "END", "COMMENT", "SEMICOLON", "COMMA", "OPEN_BRACKET", "CLOSED_BRACKET", "COLON","ERROR", "ENDMARK", "END_OF_FILE" };
const string keywords[50] = { "int" , "tree", "while", "for", "declare", "set", "to", "do", "if", "then", "else", "cin", "cout", "jump", "switch", "case", "default", "end", "bad", "begin" };

typedef LexemeTokenClass Lexeme;
typedef SymbolicTokenClass Symbol;

struct SymbolicToken
{
	Symbol symbol;
	int value;
};

struct LexemeToken
{
	Lexeme lexeme;
	int line;
	void* value;
	friend ostream& operator<<(ostream& os, const LexemeToken& lex)
	{
		os << "  " << lex.line << "\t" << LexemeTokenClassName[(int)lex.lexeme];
		if (lex.lexeme == Lexeme::COMMENT) {
			os << '\t' << *(string*)lex.value;
		}
		return os;
	}
};

class Parser {
private:
	vector<Variable*> constTable;
	vector<Variable*> nameTable;
	vector<string> markTable;
	vector<LexemeToken> lexemeList;

	SymbolicToken s;

	typedef State(Parser::* function_pointer)();
	map<State, map<Symbol, function_pointer>> automata;

	LexemeTokenClass lexeme_class;
	void* ptr;
	int num;
	int rel;
	int pos;
	int value;
	int line = 1;
	bool flag_const;
	string name;
	string tree;
	string comment;

	struct SearchTableClass
	{
		char letter;
		int alt;
		function_pointer f;
	};

	SearchTableClass table_search[400];

	int init_vector[26] = { 1, 2, 8, 25, 37, 42, 0, 0, 47, 54, 0, 0, 57, 0, 0, 0, 0, 0, 61, 68, 0, 0, 75, 0, 0, 0 };

	static SymbolicToken transliterator(int ch)
	{
		SymbolicToken s;
		s.value = 0;
		if (isdigit(ch))
		{
			s.symbol = Symbol::Digit;
			s.value = ch - '0';
		}
		else if (isalpha(ch))
		{
			s.symbol = Symbol::Letter;
			s.value = ch;
		}
		else if (ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '%')
		{
			s.symbol = Symbol::Arithmet;
			s.value = ch;
		}
		else if (ch == '=' || ch == '!' || ch == '>' || ch == '<')
		{
			s.symbol = Symbol::Relation;
			s.value = ch;
		}
		else if (ch == ' ' || ch == '\t')
		{
			s.symbol = Symbol::Space;
			s.value = ch;
		}
		else if (ch == '\n')
		{
			s.symbol = Symbol::LF;
			s.value = ch;
		}
		else if (ch == ':')
		{
			s.symbol = Symbol::Colon;
			s.value = ch;
		}
		else if (ch == ';')
		{
			s.symbol = Symbol::Semicolon;
			s.value = ch;
		}
		else if (ch == '{')
		{
			s.symbol = Symbol::OpenCurveBracket;
			s.value = ch;
		}
		else if (ch == '}')
		{
			s.symbol = Symbol::ClosedCurveBracket;
			s.value = ch;
		}
		else if (ch == '(')
		{
			s.symbol = Symbol::OpenBracket;
			s.value = ch;
		}
		else if (ch == ')')
		{
			s.symbol = Symbol::ClosedBracket;
			s.value = ch;
		}
		else if (ch == ',')
		{
			s.symbol = Symbol::Comma;
			s.value = ch;
		}
		else if (ch == EOF)
		{
			s.symbol = Symbol::EndOfFile;
			s.value = ch;
		}
		else
		{
			s.symbol = Symbol::Error;
		}
		return s;
	}

	void CreateLexeme()
	{
		LexemeToken lexeme_token;
		lexeme_token.lexeme = lexeme_class;
		lexeme_token.line = line;

		if (lexeme_class == Lexeme::ARITHMET || lexeme_class == Lexeme::COLON || lexeme_class == Lexeme::SEMICOLON || lexeme_class == Lexeme::COMMA || lexeme_class == Lexeme::OPEN_BRACKET || lexeme_class == Lexeme::CLOSED_BRACKET) {
			int* a = new int(value);
			lexeme_token.value = a;
		}
		else if (lexeme_class == Lexeme::RELATION)
		{
			int* token_rel = new int;
			*token_rel = rel;
			lexeme_token.value = token_rel;
		}
		else if (lexeme_class == Lexeme::COMMENT) {
			lexeme_token.value = new string(comment);
		}

		lexemeList.push_back(lexeme_token);

	}
	int AddVariable()
	{
		//for (string s : keywords)
		//{
		//	if (s == name) return Err();
		//}
		for (Variable* i : nameTable)
		{
			if (name == i->getName())
			{
				ptr = i;
				return 0;
			}
		}
		nameTable.push_back(new Variable(name, 0, 0));
		ptr = nameTable[nameTable.size() - 1];
		return 0;
	}

	void AddConst()
	{
		if (tree.empty())
		{
			for (Variable* i : constTable)
			{
				if (i->getType() != 0) continue;
				if (num == *(int*)(i->getValue()))
				{
					ptr = i;
					return;
				}
			}
			constTable.push_back(new Variable("", num, 0));
			ptr = constTable[constTable.size() - 1];
		}
		else
		{
			Tree h(tree);
			tree.clear();
			for (Variable* i : constTable)
			{
				if (i->getType() != 1) continue;
				if ((*(Tree*)(i->getValue())).getRoot())
					if (h.equal(*(Tree*)(i->getValue())))
					{
						ptr = i;
						return;
					}
			}
			constTable.push_back(new Variable("", h, 1));
			ptr = constTable[constTable.size() - 1];
		}
	}

	void AddMark() {
		/*for (string s : keywords)
		{
			if (s == name) return Err();
		}*/
		for (string i : markTable)
		{
			if (name == i)
			{
				return;
			}
		}
		markTable.push_back(name);
		return;
	}

	State A1()
	{
		return State::A1;
	}

	State B1()
	{
		return State::B1;
	}

	State C1()
	{
		return State::C1;
	}
	State C2()
	{
		return State::C1;
	}
	State C3()
	{
		return State::C3;
	}
	State C4()
	{
		return State::C4;
	}

	State D1()
	{
		return State::D1;
	}

	State E1()
	{
		return State::E1;
	}

	State E2()
	{
		return State::E2;
	}

	State E3()
	{
		return State::E3;
	}
	State F1()
	{
		return State::F1;
	}
	State F2()
	{
		return State::F2;
	}
	State F3()
	{
		return State::F3;
	}

	State G1()
	{
		return State::G1;
	}
	State G2()
	{
		return State::G2;
	}
	State G3()
	{
		return State::G3;
	}
	State G4()
	{
		return State::G4;
	}

	State H1()
	{
		return State::H1;
	}

	State I1()
	{
		return State::I1;
	}

	State I2()
	{
		return State::I2;
	}

	State J1()
	{
		return State::J1;
	}
	State A1a()
	{
		line++;
		return State::A1;
	}
	State A1b()
	{
		CreateLexeme();
		line++;
		return State::A1;
	}
	State A1c() {
		CreateLexeme();
		return State::A1;
	}
	State A1d()
	{
		if (rel == '!') return Err();
		else if (rel == '<')
		{
			rel = 3;
		}
		else if (rel == '>')
		{
			rel = 4;
		}
		lexeme_class = Lexeme::RELATION;
		if (rel == '=') {
			lexeme_class = Lexeme::ASSIGNMENT;
		}
		CreateLexeme();
		return State::A1;
	}
	State A1e()
	{
		if (rel == '!') return Err();
		else if (rel == '<')
		{
			rel = 3;
		}
		else if (rel == '>')
		{
			rel = 4;
		}
		lexeme_class = Lexeme::RELATION;
		if (rel == '=') {
			lexeme_class = Lexeme::ASSIGNMENT;
		}
		CreateLexeme();
		line++;
		return State::A1;
	}
	State A1_const()
	{
		AddConst();
		CreateLexeme();
		return State::A1;
	}
	State A1_constP()
	{
		AddConst();
		CreateLexeme();
		line++;
		return State::A1;
	}
	State A1_mark()
	{
		AddMark();
		CreateLexeme();
		return State::A1;
	}
	State A1_markP()
	{
		AddMark();
		CreateLexeme();
		line++;
		return State::A1;
	}
	State A1_var()
	{
		AddVariable();
		CreateLexeme();
		return State::A1;
	}
	State A1_varP()
	{
		AddVariable();
		CreateLexeme();
		line++;
		return State::A1;
	}
	State B1a()
	{
		pos = init_vector[s.value - 'a'];
		if (pos == 0)
		{
			return F1a();
		}
		lexeme_class = Lexeme::VARIABLE;
		if (!isalpha(s.value)) s.value += '0';
		name = (char)s.value;
		return State::B1;
	}
	State B1b()
	{
		pos++;
		return State::B1;
	}
	State C1c()
	{
		if (s.value == '=')
		{
			if (rel == '=')
			{
				rel = 1;
			}
			else if (rel == '!')
			{
				rel = 2;
			}
			else if (rel == '<')
			{
				rel = 5;
			}
			else if (rel == '>')
			{
				rel = 6;
			}
		}
		else
		{
			return Err();
		}
		lexeme_class = Lexeme::RELATION;
		return State::C1;
	}
	State C1_constTree() {
		lexeme_class = Lexeme::CONST;
		tree = tree + (char)s.value;
		AddConst();
		return State::C1;
	}
	State C1_semicolon() {
		lexeme_class = Lexeme::SEMICOLON;
		value = s.value;
		return State::C1;
	}
	State C1_openBracket() {
		lexeme_class = Lexeme::OPEN_BRACKET;
		value = s.value;
		return State::C1;
	}
	State C1_int() {
		lexeme_class = Lexeme::INT;
		return State::C1;
	}
	State C1_at() {
		lexeme_class = Lexeme::AT;
		return State::C1;
	}
	State C1_composition() {
		lexeme_class = Lexeme::COMPOSITION;
		return State::C1;
	}
	State C1_find() {
		lexeme_class = Lexeme::FIND;
		return State::C1;
	}
	State C1_invert() {
		lexeme_class = Lexeme::INVERT;
		return State::C1;
	}
	State C1_merge() {
		lexeme_class = Lexeme::MERGE;
		return State::C1;
	}
	State C1_closedBracekt() {
		lexeme_class = Lexeme::CLOSED_BRACKET;
		value = s.value;
		return State::C1;
	}
	State C1_comma() {
		lexeme_class = Lexeme::COMMA;
		value = s.value;
		return State::C1;
	}
	State C1_bad() {
		lexeme_class = Lexeme::BAD;
		return State::C1;
	}
	State C1_begin() {
		lexeme_class = Lexeme::BEGIN;
		return State::C1;
	}
	State C1_case() {
		lexeme_class = Lexeme::CASE;
		return State::C1;
	}
	State C1_cin() {
		lexeme_class = Lexeme::CIN;
		return State::C1;
	}
	State C1_cout() {
		lexeme_class = Lexeme::COUT;
		return State::C1;
	}
	State C1_declare() {
		lexeme_class = Lexeme::DECLARE;
		return State::C1;
	}
	State C1_default() {
		lexeme_class = Lexeme::DEFAULT;
		return State::C1;
	}
	State C1_do() {
		lexeme_class = Lexeme::DO;
		return State::C1;
	}
	State C1_else() {
		lexeme_class = Lexeme::ELSE;
		return State::C1;
	}
	State C1_end() {
		lexeme_class = Lexeme::END;
		return State::C1;
	}
	State C1_for() {
		lexeme_class = Lexeme::FOR;
		return State::C1;
	}
	State C1_if() {
		lexeme_class = Lexeme::IF;
		return State::C1;
	}
	State C1_tree() {
		lexeme_class = Lexeme::TREE;
		return State::C1;
	}
	State C1_set() {
		lexeme_class = Lexeme::SET;
		return State::C1;
	}
	State C1_switch() {
		lexeme_class = Lexeme::SWITCH;
		return State::C1;
	}
	State C1_then() {
		lexeme_class = Lexeme::THEN;
		return State::C1;
	}
	State C1_to() {
		lexeme_class = Lexeme::TO;
		return State::C1;
	}
	State C1_while() {
		lexeme_class = Lexeme::WHILE;
		return State::C1;
	}
	State C1_ArrowL() {
		if (s.value == '-' && rel == '<') {
			lexeme_class = Lexeme::ARROW_LEFT;
		}
		else {
			return Err();
		}
		return State::C1;
	}
	State C1_ArrowR() {
		if (value == '-' && s.value == '>') {
			lexeme_class = Lexeme::ARROW_RIGHT;
		}
		else {
			return Err();
		}
		return State::C1;
	}
	State C2a() {
		lexeme_class = Lexeme::ARITHMET;
		value = s.value;
		return State::C2;
	}
	State C3_jump() {
		lexeme_class = Lexeme::JUMP;
		name.clear();
		return State::C3;
	}
	State C4a() {
		if (!isalpha(s.value)) s.value += '0';
		name += (char)s.value;
		return State::C4;
	}
	State D1a() {
		lexeme_class = Lexeme::RELATION;
		rel = s.value;
		return State::D1;
	}
	State E1a() {
		lexeme_class = Lexeme::COLON;
		value = s.value;
		return E1();
	}
	State E2a() {
		lexeme_class = Lexeme::MARK;
		if (!isalpha(s.value)) s.value += '0';
		name = (char)s.value;
		return State::E2;
	}
	State E2b() {
		if (!isalpha(s.value)) s.value += '0';
		name += (char)s.value;
		return State::E2;
	}
	State F1a() {
		lexeme_class = Lexeme::VARIABLE;
		if (!isalpha(s.value)) s.value += '0';
		name = (char)s.value;
		return State::F1;
	}
	State F1b() {
		lexeme_class = Lexeme::VARIABLE;
		if (!isalpha(s.value)) s.value += '0';
		name += (char)s.value;
		return State::F1;
	}
	State G1a() {
		tree.clear();
		lexeme_class = Lexeme::CONST;
		num = s.value;
		return State::G1;
	}
	State G1b()
	{
		num = 10 * num + s.value;
		return State::G1;
	}
	State G2a() {
		rel = 0;
		tree = (char)s.value;
		return State::G2;
	}
	State G2b() {
		tree = tree + (char)(s.value + '0');
		return State::G2;
	}
	State G3a()
	{
		if (s.value != '>') return Err();
		tree = tree + (char)s.value;
		return State::G3;
	}
	State G3b() {
		tree = tree + (char)(s.value + '0');
		return State::G3;
	}
	State G4a() {
		tree = tree + (char)s.value;
		return State::G4;
	}
	State I1a() {
		if (value == '-' && s.value == '-') {
			lexeme_class = Lexeme::COMMENT;
			comment = "";
			return State::I1;
		}
		else {
			return Err();
		}
	}
	State I1b() {
		if (s.symbol == Symbol::Digit)
		{
			comment = comment + (char)(s.value + '0');
		}
		else {
			comment = comment + (char)s.value;
		}
		return State::I1;
	}
	State M1()
	{
		if (table_search[pos].letter == s.value)
		{
			if (!isalpha(s.value)) s.value += '0';
			name += (char)s.value;
			return (this->*table_search[pos].f)();
		}
		else
		{
			pos = table_search[pos].alt;
			if (pos == 0)
			{
				return F1b();
			}
			else
			{
				return M1();
			}
		}
	}



	State Err() {
		lexeme_class = Lexeme::ERROR;
		CreateLexeme();
		cout << "Error line: " << line << endl;
		return State::J1;
	}
	State Exit1()
	{
		lexeme_class = Lexeme::ENDMARK;
		CreateLexeme();
		return State::Exit;
	}
	State Exit2()
	{
		CreateLexeme();
		lexeme_class = Lexeme::ENDMARK;
		CreateLexeme();
		return State::Exit;
	}
	State Exit3()
	{
		AddConst();
		CreateLexeme();
		lexeme_class = Lexeme::ENDMARK;
		CreateLexeme();
		return State::Exit;
	}
	State Exit4()
	{
		AddVariable();
		CreateLexeme();
		lexeme_class = Lexeme::ENDMARK;
		CreateLexeme();
		return State::Exit;
	}
	State Exit5()
	{
		AddMark();
		CreateLexeme();
		lexeme_class = Lexeme::ENDMARK;
		CreateLexeme();
		return State::Exit;
	}
public:
	Parser()
	{

		automata = {
			{State::A1,	{{ Symbol::Letter, &Parser::B1a},	{ Symbol::Digit, &Parser::G1a},	{ Symbol::Arithmet, &Parser::C2a},			{ Symbol::Relation, &Parser::D1a},			{ Symbol::Space, &Parser::A1},			{ Symbol::LF, &Parser::A1a},		{ Symbol::Semicolon, &Parser::C1_semicolon},	{ Symbol::Colon, &Parser::E1a},	{ Symbol::OpenCurveBracket, &Parser::G2a},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::C1_openBracket},	{ Symbol::ClosedBracket, &Parser::C1_closedBracekt},	{ Symbol::Comma, &Parser::C1_comma},	{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Exit1}}},
			{State::B1,	{{ Symbol::Letter, &Parser::M1},	{ Symbol::Digit, &Parser::Err},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::Err},			{ Symbol::Space, &Parser::A1_var},		{ Symbol::LF, &Parser::A1_varP},	{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Exit4}}},
			{State::C1,	{{ Symbol::Letter, &Parser::F1b},	{ Symbol::Digit, &Parser::F1b},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::Err},			{ Symbol::Space, &Parser::A1c},			{ Symbol::LF, &Parser::A1b},		{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Exit2}}},
			{State::C2,	{{ Symbol::Letter, &Parser::Err},	{ Symbol::Digit, &Parser::Err},	{ Symbol::Arithmet, &Parser::I1a},			{ Symbol::Relation, &Parser::C1_ArrowR},	{ Symbol::Space, &Parser::A1c},			{ Symbol::LF, &Parser::A1b},		{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Exit2}}},
			{State::C3,	{{ Symbol::Letter, &Parser::C4a},	{ Symbol::Digit, &Parser::Err},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::Err},			{ Symbol::Space, &Parser::C3},			{ Symbol::LF, &Parser::Err},		{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Err}}},
			{State::C4,	{{ Symbol::Letter, &Parser::C4a},	{ Symbol::Digit, &Parser::C4a},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::Err},			{ Symbol::Space, &Parser::A1c},			{ Symbol::LF, &Parser::A1b},		{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Exit2}}},
			{State::D1,	{{ Symbol::Letter, &Parser::Err},	{ Symbol::Digit, &Parser::Err},	{ Symbol::Arithmet, &Parser::C1_ArrowL},	{ Symbol::Relation, &Parser::C1c},			{ Symbol::Space, &Parser::A1d},			{ Symbol::LF, &Parser::A1e},		{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Exit2}}},
			{State::E1,	{{ Symbol::Letter, &Parser::E2a},	{ Symbol::Digit, &Parser::Err},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::Err},			{ Symbol::Space, &Parser::A1c},			{ Symbol::LF, &Parser::A1b},		{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Exit2}}},
			{State::E2,	{{ Symbol::Letter, &Parser::E2b},	{ Symbol::Digit, &Parser::E2b},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::Err},			{ Symbol::Space, &Parser::A1_mark},		{ Symbol::LF, &Parser::A1_markP},	{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Exit5}}},
			{State::F1,	{{ Symbol::Letter, &Parser::F1b},	{ Symbol::Digit, &Parser::F1b},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::Err},			{ Symbol::Space, &Parser::A1_var},		{ Symbol::LF, &Parser::A1_varP},	{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Exit4}}},
			{State::G1,	{{ Symbol::Letter, &Parser::Err},	{ Symbol::Digit, &Parser::G1b},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::Err},			{ Symbol::Space, &Parser::A1_const},	{ Symbol::LF, &Parser::A1_constP},	{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Exit3}}},
			{State::G2,	{{ Symbol::Letter, &Parser::Err},	{ Symbol::Digit, &Parser::G2b},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::G3a},			{ Symbol::Space, &Parser::Err},			{ Symbol::LF, &Parser::Err},		{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Err}}},
			{State::G3,	{{ Symbol::Letter, &Parser::Err},	{ Symbol::Digit, &Parser::G3b},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::Err},			{ Symbol::Space, &Parser::Err},			{ Symbol::LF, &Parser::Err},		{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::C1_constTree},	{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::G4a},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Err}}},
			{State::G4,	{{ Symbol::Letter, &Parser::Err},	{ Symbol::Digit, &Parser::G2b},	{ Symbol::Arithmet, &Parser::Err},			{ Symbol::Relation, &Parser::Err},			{ Symbol::Space, &Parser::G4},			{ Symbol::LF, &Parser::Err},		{ Symbol::Semicolon, &Parser::Err},				{ Symbol::Colon, &Parser::Err},	{ Symbol::OpenCurveBracket, &Parser::Err},	{ Symbol::ClosedCurveBracket, &Parser::Err},			{ Symbol::OpenBracket, &Parser::Err},				{ Symbol::ClosedBracket, &Parser::Err},					{ Symbol::Comma, &Parser::Err},			{ Symbol::Error, &Parser::Err},	{ Symbol::EndOfFile, &Parser::Err}}},
			{State::I1,	{{ Symbol::Letter, &Parser::I1b},	{ Symbol::Digit, &Parser::I1b},	{ Symbol::Arithmet, &Parser::I1b},			{ Symbol::Relation, &Parser::I1b},			{ Symbol::Space, &Parser::I1b},			{ Symbol::LF, &Parser::A1b},		{ Symbol::Semicolon, &Parser::I1b},				{ Symbol::Colon, &Parser::I1b},	{ Symbol::OpenCurveBracket, &Parser::I1b},	{ Symbol::ClosedCurveBracket, &Parser::I1b},			{ Symbol::OpenBracket, &Parser::I1b},				{ Symbol::ClosedBracket, &Parser::I1b},					{ Symbol::Comma, &Parser::I1b},			{ Symbol::Error, &Parser::I1b},	{ Symbol::EndOfFile, &Parser::Exit2}}},
			{State::J1,	{{ Symbol::Letter, &Parser::J1},	{ Symbol::Digit, &Parser::J1},	{ Symbol::Arithmet, &Parser::J1},			{ Symbol::Relation, &Parser::J1},			{ Symbol::Space, &Parser::J1},			{ Symbol::LF, &Parser::A1a},		{ Symbol::Semicolon, &Parser::J1},				{ Symbol::Colon, &Parser::J1},	{ Symbol::OpenCurveBracket, &Parser::J1},	{ Symbol::ClosedCurveBracket, &Parser::J1},				{ Symbol::OpenBracket, &Parser::J1},				{ Symbol::ClosedBracket, &Parser::J1},					{ Symbol::Comma, &Parser::J1},			{ Symbol::Error, &Parser::J1},	{ Symbol::EndOfFile, &Parser::Exit1}}},
		};

		for (int i = 0; i < 400; i++) table_search[i].f = &Parser::B1b;

		//at
		table_search[1].letter = 't';	table_search[1].f = &Parser::C1_at;
		//bad
		table_search[2].letter = 'a';												table_search[2].alt = 4;
		table_search[3].letter = 'd';	table_search[3].f = &Parser::C1_bad;
		//begin
		table_search[4].letter = 'e';
		table_search[5].letter = 'g';
		table_search[6].letter = 'i';
		table_search[7].letter = 'n';	table_search[7].f = &Parser::C1_begin;
		//case
		table_search[8].letter = 'a';												table_search[8].alt = 11;
		table_search[9].letter = 's';
		table_search[10].letter = 'e';	table_search[10].f = &Parser::C1_case;
		//cin
		table_search[11].letter = 'i';												table_search[11].alt = 13;
		table_search[12].letter = 'n';	table_search[12].f = &Parser::C1_cin;
		//composition
		table_search[13].letter = 'o';
		table_search[14].letter = 'm';												table_search[14].alt = 23;
		table_search[15].letter = 'p';
		table_search[16].letter = 'o';
		table_search[17].letter = 's';
		table_search[18].letter = 'i';
		table_search[19].letter = 't';
		table_search[20].letter = 'i';
		table_search[21].letter = 'o';
		table_search[22].letter = 'n';	table_search[22].f = &Parser::C1_composition;
		//cout
		table_search[23].letter = 'u';
		table_search[24].letter = 't';	table_search[24].f = &Parser::C1_cout;
		//declare
		table_search[25].letter = 'e';												table_search[25].alt = 36;
		table_search[26].letter = 'c';												table_search[26].alt = 31;
		table_search[27].letter = 'l';
		table_search[28].letter = 'a';
		table_search[29].letter = 'r';
		table_search[30].letter = 'e';	table_search[30].f = &Parser::C1_declare;
		//default
		table_search[31].letter = 'f';
		table_search[32].letter = 'a';
		table_search[33].letter = 'u';
		table_search[34].letter = 'l';
		table_search[35].letter = 't';	table_search[35].f = &Parser::C1_default;
		//do
		table_search[36].letter = 'o';	table_search[36].f = &Parser::C1_do;
		//else
		table_search[37].letter = 'l';												table_search[37].alt = 40;
		table_search[38].letter = 's';
		table_search[39].letter = 'e';	table_search[39].f = &Parser::C1_else;
		//end
		table_search[40].letter = 'n';
		table_search[41].letter = 'd';	table_search[41].f = &Parser::C1_end;
		//find
		table_search[42].letter = 'i';												table_search[42].alt = 45;
		table_search[43].letter = 'n';
		table_search[44].letter = 'd';	table_search[44].f = &Parser::C1_find;
		//for
		table_search[45].letter = 'o';
		table_search[46].letter = 'r';	table_search[46].f = &Parser::C1_for;
		//if
		table_search[47].letter = 'f';	table_search[47].f = &Parser::C1_if;		table_search[47].alt = 48;
		//int
		table_search[48].letter = 'n';
		table_search[49].letter = 't';	table_search[49].f = &Parser::C1_int;		table_search[49].alt = 50;
		//invert
		table_search[50].letter = 'v';
		table_search[51].letter = 'e';
		table_search[52].letter = 'r';
		table_search[53].letter = 't';	table_search[53].f = &Parser::C1_invert;
		//jump
		table_search[54].letter = 'u';
		table_search[55].letter = 'm';
		table_search[56].letter = 'p';	table_search[56].f = &Parser::C3_jump;
		//merge
		table_search[57].letter = 'e';
		table_search[58].letter = 'r';
		table_search[59].letter = 'g';
		table_search[60].letter = 'e'; table_search[60].f = &Parser::C1_merge;
		//set
		table_search[61].letter = 'e';												table_search[61].alt = 63;
		table_search[62].letter = 't';	table_search[62].f = &Parser::C1_set;
		//switch
		table_search[63].letter = 'w';
		table_search[64].letter = 'i';
		table_search[65].letter = 't';
		table_search[66].letter = 'c';
		table_search[67].letter = 'h';	table_search[67].f = &Parser::C1_switch;
		//then
		table_search[68].letter = 'h';												table_search[68].alt = 71;
		table_search[69].letter = 'e';
		table_search[70].letter = 'n';	table_search[70].f = &Parser::C1_then;
		//to
		table_search[71].letter = 'o';	table_search[71].f = &Parser::C1_to;		table_search[71].alt = 72;
		//tree
		table_search[72].letter = 'r';
		table_search[73].letter = 'e';
		table_search[74].letter = 'e';	table_search[74].f = &Parser::C1_tree;
		//while
		table_search[75].letter = 'h';
		table_search[76].letter = 'i';
		table_search[77].letter = 'l';
		table_search[78].letter = 'e';	table_search[78].f = &Parser::C1_while;
	}

	void printLists() {
		cout << "table_const\nAdress\t\t\tName" << endl;
		for (auto i : constTable) {
			cout << i << "\t\t";
			if (i->getType() == 0) {
				cout << *(int*)(i->getValue()) << endl;
			}
			else {
				cout << *(Tree*)(i->getValue()) << endl;
			}
		}

		cout << endl << "Variable table\nAdress\t\t\tName" << endl;
		for (auto i : nameTable)
			cout << i << "\t\t" << i->getName() << endl;

		cout << endl << "Label table\nAdress\t\t\tName" << endl;
		for (auto i : markTable)
			cout << &i << "\t\t" << i << endl;


		cout << endl << "Lexeme list\nLine\tClass" << endl;
		for (int i = 0; i < lexemeList.size(); i++) {
			cout << lexemeList[i] << endl;
		}
		cout << endl;
	}

	void parse(const char* filename) {
		ifstream in(filename);
		if (!in)
		{
			cout << "Open Error " << filename << endl;
			return;
		}

		int ch;
		State state = State::A1;
		while (state != State::Exit)
		{
			ch = in.get();
			s = transliterator(ch);
			state = (this->*automata[state][s.symbol])();
		}
		printLists();
		in.close();
	}

	vector<LexemeToken> getLexemeList() {
		return lexemeList;
	}
};